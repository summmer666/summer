document.getElementById('registerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const response = await fetch('/users/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });
    const result = await response.text();
    if (response.ok) {
        alert('用户注册成功！');
    } else {
        document.getElementById('registerError').textContent = result;
    }
});

document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    const response = await fetch('/users/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    });
    const result = await response.json();
    if (response.ok) {
        alert('用户登录成功！');
        // 可以在这里处理登录后的用户信息，比如存储在localStorage中
    } else {
        document.getElementById('loginError').textContent = '用户名或密码错误';
    }
});