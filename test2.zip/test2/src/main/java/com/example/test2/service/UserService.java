package com.example.test2.service;

import com.example.test2.dao.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private com.example.test2.mapper.UsersMapper UsersMapper;

    public boolean registerUser(Users user) {
        // 你可以在这里添加一些业务逻辑，比如验证用户名是否已存在
        // 如果用户名已存在，则返回false
        Users existingUser = UsersMapper.selectUserByUsername(user.getUsername());
        if (existingUser != null) {
            return false; // 用户名已存在
        }
        // 插入新用户
        int rowsInserted = UsersMapper.insertUser(user);
        return rowsInserted > 0; // 如果插入成功，则返回true
    }

    public Users login(String username, String password) {
        return UsersMapper.selectUserByUsernameAndPassword(username, password);
    }
}
