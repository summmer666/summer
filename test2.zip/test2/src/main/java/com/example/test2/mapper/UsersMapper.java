package com.example.test2.mapper;

import com.example.test2.dao.Users;
import org.apache.ibatis.annotations.*;

@Mapper
public interface UsersMapper {
    @Insert("INSERT INTO users (username, password) VALUES (#{username}, #{password})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insertUser(Users user);

    @Select("SELECT * FROM users WHERE username = #{username}")
    Users selectUserByUsername(String username);

    @Select("SELECT * FROM users WHERE username = #{username} AND password = #{password}")
    Users selectUserByUsernameAndPassword(@Param("username") String username, @Param("password") String password);

    @Select("SELECT CASE WHEN COUNT(*) > 0 THEN TRUE ELSE FALSE END FROM users WHERE username = #{username}")
    boolean usernameExists(String username);


    @Select("SELECT * FROM users WHERE id = #{id}")
    Users selectUserById(int id);
}
