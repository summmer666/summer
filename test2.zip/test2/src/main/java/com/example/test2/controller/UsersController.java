package com.example.test2.controller;
import com.example.test2.dao.Users;
import com.example.test2.mapper.UsersMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/users")
public class UsersController {

    @Autowired
    private UsersMapper usersMapper; // 假设你已经有一个UsersMapper接口用于数据访问

    // 用户注册
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody Users user) {
        // 检查用户名是否已存在
        if (usersMapper.usernameExists(user.getUsername())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already exists!");
        }
        // 注册用户
        usersMapper.insertUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully!");
    }

    // 用户登录
    @PostMapping("/login")
    public ResponseEntity<Users> loginUser(@RequestBody Users loginRequest) {
        // 根据用户名和密码登录
        Users user = usersMapper.selectUserByUsernameAndPassword(loginRequest.getUsername(), loginRequest.getPassword());
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        return ResponseEntity.ok(user);
    }

    // 获取用户信息（根据ID）
    @GetMapping("/{id}")
    public ResponseEntity<Users> getUserById(@PathVariable int id) {
        Users user = usersMapper.selectUserById(id);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.ok(user);
    }

    // 其他与用户相关的RESTful方法...
}
